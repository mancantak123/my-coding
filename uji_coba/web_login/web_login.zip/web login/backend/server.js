import http from "http";
import fs from "fs";

const db_path = "./data.json";
const port = 3000;

function readData() {
    const data = fs.readFileSync(db_path, "utf-8");
    return JSON.parse(data);
}

function writeData(data) {
    fs.writeFileSync(db_path, JSON.stringify(data, null, 2), "utf-8");
}

const server = http.createServer((req, res) => {
    res.setHeader("Access-Control-Allow-Origin", "*"); 
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") {
        res.writeHead(204);
        res.end();
        return;
    }

    if (req.method === "GET" && req.url === "/users") {
        const users = readData();
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify(users));
    } else if (req.method === "POST" && req.url === "/users") {
        let data = "";
        req.on("data", (chunk) => {
            data += chunk;
        });
        req.on("end", () => {
            const newUser = JSON.parse(data);
            const users = readData();
            users.user.push(newUser); 
            writeData(users);
            res.writeHead(201, { "Content-Type": "application/json" });
            res.end(JSON.stringify(newUser));
        });
    } else {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Route tidak ditemukan" }));
    }
});

server.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});