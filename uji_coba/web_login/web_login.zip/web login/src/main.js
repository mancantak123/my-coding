const email = document.getElementById("emailField");
const password = document.getElementById("passwordField");
const submit = document.querySelector("button[type='submit']");

async function ambildata() {
    const response = await fetch("../backend/data.json");
    const data = await response.json();
    return data;
}

submit.addEventListener("click", async () =>{
    const emailValue = email.value;
    const passwordValue = password.value;
    const data = await ambildata();

    const user = data.user.find(user => user.email === emailValue && user.password === passwordValue);
    if (user) {
        alert("Login berhasil!");
    } else {
        alert("Email atau password salah!");
    }
})