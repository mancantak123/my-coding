const username = document.getElementById('name');
const email = document.getElementById('email');
const password = document.getElementById('password');
const confirm = document.querySelector('.btn');

async function simpanData(usernamevalue, emailvalue, passwordvalue) {
    const response = await fetch('http://localhost:3000/users', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: usernamevalue,
            email: emailvalue,
            password: passwordvalue
        })
    });
    console.log("status", response.status);
    const data = await response.json();
    console.log(data);
}

confirm.addEventListener('click', (e) => {
    e.preventDefault();
    const usernamevalue = username.value;
    const emailvalue = email.value;
    const passwordvalue = password.value;

    simpanData(usernamevalue, emailvalue, passwordvalue);
});